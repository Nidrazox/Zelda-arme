export const weapons = [
  {
    id: 1,
    name: 'Master Sword',
    attackPower: 30,
    durability: 40,
    rarity: 'Legendary',
    imageUrl: 'https://via.placeholder.com/250x150?text=Master+Sword',
    specialEffects: 'Glows near evil',
  },
  {
    id: 2,
    name: 'Royal Bow',
    attackPower: 38,
    durability: 60,
    rarity: 'Rare',
    imageUrl: 'https://via.placeholder.com/250x150?text=Royal+Bow',
    specialEffects: 'Long range, high accuracy',
  },
  {
    id: 3,
    name: 'Ancient Blade',
    attackPower: 50,
    durability: 25,
    rarity: 'Epic',
    imageUrl: 'https://via.placeholder.com/250x150?text=Ancient+Blade',
    specialEffects: 'Pierces armor',
  },
];
