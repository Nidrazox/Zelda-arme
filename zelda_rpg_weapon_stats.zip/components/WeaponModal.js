import React from 'react';

export default function WeaponModal({ weapon, onClose }) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-md w-full p-6 relative shadow-lg">
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-gray-600 hover:text-gray-900 text-xl font-bold"
          aria-label="Close modal"
        >
          &times;
        </button>
        <img
          src={weapon.imageUrl}
          alt={weapon.name}
          className="w-full h-48 object-cover rounded-md mb-4"
        />
        <h2 className="text-2xl font-bold mb-2">{weapon.name}</h2>
        <p><strong>Attack Power:</strong> {weapon.attackPower}</p>
        <p><strong>Durability:</strong> {weapon.durability}</p>
        <p><strong>Rarity:</strong> {weapon.rarity}</p>
        <p><strong>Special Effects:</strong> {weapon.specialEffects || 'None'}</p>
      </div>
    </div>
  );
}
