import React from 'react';

export default function WeaponCard({ weapon, onView, onEdit, onToggleCompare, isCompared }) {
  return (
    <div className="weapon-card bg-white rounded-lg shadow-md p-4 flex flex-col">
      <img
        src={weapon.imageUrl}
        alt={weapon.name}
        className="rounded-md mb-3 object-cover h-40"
      />
      <h3 className="text-xl font-semibold mb-1">{weapon.name}</h3>
      <p><strong>Attack Power:</strong> {weapon.attackPower}</p>
      <p><strong>Durability:</strong> {weapon.durability}</p>
      <p><strong>Rarity:</strong> {weapon.rarity}</p>

      <div className="mt-auto flex space-x-2 pt-3">
        <button
          onClick={onView}
          className="flex-1 bg-blue-600 text-white py-2 rounded hover:bg-blue-700"
        >
          View
        </button>
        <button
          onClick={onEdit}
          className="flex-1 bg-yellow-500 text-white py-2 rounded hover:bg-yellow-600"
        >
          Edit
        </button>
        <button
          onClick={onToggleCompare}
          className={`flex-1 py-2 rounded border 
            ${isCompared ? 'bg-green-600 text-white border-green-600' : 'bg-white text-gray-700 border-gray-400'}
            hover:bg-green-700 hover:text-white`}
        >
          {isCompared ? 'Remove' : 'Compare'}
        </button>
      </div>
    </div>
  );
}
