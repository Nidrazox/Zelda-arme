import React from 'react';

export default function ComparisonModal({ weapons, onClose }) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 overflow-auto">
      <div className="bg-white rounded-lg max-w-5xl w-full p-6 shadow-lg relative">
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-gray-600 hover:text-gray-900 text-xl font-bold"
          aria-label="Close comparison modal"
        >
          &times;
        </button>
        <h2 className="text-2xl font-bold mb-4 text-center">Weapon Comparison</h2>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse border border-gray-300 text-center">
            <thead>
              <tr>
                <th className="border border-gray-300 p-2">Stat / Weapon</th>
                {weapons.map((w) => (
                  <th key={w.id} className="border border-gray-300 p-2">{w.name}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border border-gray-300 p-2 font-semibold">Attack Power</td>
                {weapons.map((w) => (
                  <td key={w.id} className="border border-gray-300 p-2">{w.attackPower}</td>
                ))}
              </tr>
              <tr>
                <td className="border border-gray-300 p-2 font-semibold">Durability</td>
                {weapons.map((w) => (
                  <td key={w.id} className="border border-gray-300 p-2">{w.durability}</td>
                ))}
              </tr>
              <tr>
                <td className="border border-gray-300 p-2 font-semibold">Rarity</td>
                {weapons.map((w) => (
                  <td key={w.id} className="border border-gray-300 p-2">{w.rarity}</td>
                ))}
              </tr>
              <tr>
                <td className="border border-gray-300 p-2 font-semibold">Special Effects</td>
                {weapons.map((w) => (
                  <td key={w.id} className="border border-gray-300 p-2">{w.specialEffects || 'None'}</td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
