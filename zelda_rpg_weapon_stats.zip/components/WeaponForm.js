import React, { useState, useEffect } from 'react';

export default function WeaponForm({ weapon, onClose, onSave }) {
  const [formData, setFormData] = useState({
    id: weapon?.id || null,
    name: weapon?.name || '',
    attackPower: weapon?.attackPower || '',
    durability: weapon?.durability || '',
    rarity: weapon?.rarity || '',
    imageUrl: weapon?.imageUrl || '',
    specialEffects: weapon?.specialEffects || '',
  });

  useEffect(() => {
    if (weapon) {
      setFormData({
        id: weapon.id,
        name: weapon.name,
        attackPower: weapon.attackPower,
        durability: weapon.durability,
        rarity: weapon.rarity,
        imageUrl: weapon.imageUrl,
        specialEffects: weapon.specialEffects || '',
      });
    }
  }, [weapon]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!formData.name || !formData.attackPower || !formData.durability || !formData.rarity) {
      alert('Please fill in all required fields.');
      return;
    }

    onSave({
      ...formData,
      attackPower: Number(formData.attackPower),
      durability: Number(formData.durability),
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <form
        onSubmit={handleSubmit}
        className="bg-white rounded-lg max-w-md w-full p-6 shadow-lg"
      >
        <h2 className="text-2xl font-bold mb-4">{weapon ? 'Edit Weapon' : 'Add New Weapon'}</h2>

        <label className="block mb-2">
          Name*:
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            className="w-full border border-gray-300 rounded px-3 py-2 mt-1"
            required
          />
        </label>

        <label className="block mb-2">
          Attack Power*:
          <input
            type="number"
            name="attackPower"
            value={formData.attackPower}
            onChange={handleChange}
            className="w-full border border-gray-300 rounded px-3 py-2 mt-1"
            required
            min="1"
          />
        </label>

        <label className="block mb-2">
          Durability*:
          <input
            type="number"
            name="durability"
            value={formData.durability}
            onChange={handleChange}
            className="w-full border border-gray-300 rounded px-3 py-2 mt-1"
            required
            min="1"
          />
        </label>

        <label className="block mb-2">
          Rarity*:
          <select
            name="rarity"
            value={formData.rarity}
            onChange={handleChange}
            className="w-full border border-gray-300 rounded px-3 py-2 mt-1"
            required
          >
            <option value="">Select rarity</option>
            <option value="Common">Common</option>
            <option value="Uncommon">Uncommon</option>
            <option value="Rare">Rare</option>
            <option value="Epic">Epic</option>
            <option value="Legendary">Legendary</option>
          </select>
        </label>

        <label className="block mb-2">
          Image URL:
          <input
            type="url"
            name="imageUrl"
            value={formData.imageUrl}
            onChange={handleChange}
            className="w-full border border-gray-300 rounded px-3 py-2 mt-1"
          />
        </label>

        <label className="block mb-4">
          Special Effects:
          <textarea
            name="specialEffects"
            value={formData.specialEffects}
            onChange={handleChange}
            className="w-full border border-gray-300 rounded px-3 py-2 mt-1"
            rows="3"
          />
        </label>

        <div className="flex justify-between">
          <button
            type="button"
            onClick={onClose}
            className="bg-gray-400 text-white px-4 py-2 rounded hover:bg-gray-500"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
          >
            Save
          </button>
        </div>
      </form>
    </div>
  );
}
