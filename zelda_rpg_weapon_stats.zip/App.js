import React, { useState } from 'react';
import './App.css';
import WeaponCard from './components/WeaponCard';
import WeaponModal from './components/WeaponModal';
import WeaponForm from './components/WeaponForm';
import ComparisonModal from './components/ComparisonModal';
import { weapons as initialWeapons } from './mockData';

function App() {
  const [weapons, setWeapons] = useState(initialWeapons);
  const [selectedWeapon, setSelectedWeapon] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [weaponToEdit, setWeaponToEdit] = useState(null);
  const [comparisonList, setComparisonList] = useState([]);
  const [isComparisonOpen, setIsComparisonOpen] = useState(false);

  const openModal = (weapon) => {
    setSelectedWeapon(weapon);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setSelectedWeapon(null);
    setIsModalOpen(false);
  };

  const openForm = (weapon = null) => {
    setWeaponToEdit(weapon);
    setIsFormOpen(true);
  };

  const closeForm = () => {
    setWeaponToEdit(null);
    setIsFormOpen(false);
  };

  const saveWeapon = (weaponData) => {
    if (weaponToEdit) {
      setWeapons(weapons.map(w => w.id === weaponData.id ? weaponData : w));
    } else {
      setWeapons([...weapons, {...weaponData, id: Date.now()}]);
    }
    closeForm();
  };

  const toggleComparison = (weapon) => {
    const isInList = comparisonList.find(w => w.id === weapon.id);
    if (isInList) {
      setComparisonList(comparisonList.filter(w => w.id !== weapon.id));
    } else if (comparisonList.length < 3) {
      setComparisonList([...comparisonList, weapon]);
    }
  };

  const openComparison = () => {
    if (comparisonList.length > 1) {
      setIsComparisonOpen(true);
    } else {
      alert('Select at least two weapons to compare.');
    }
  };

  const closeComparison = () => {
    setIsComparisonOpen(false);
  };

  return (
    <div className="App container mx-auto p-4">
      <header className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Zelda RPG - Weapon Stats</h1>
        <button
          className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
          onClick={() => openForm()}
        >
          Add Weapon
        </button>
      </header>

      <main>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {weapons.map((weapon) => (
            <WeaponCard
              key={weapon.id}
              weapon={weapon}
              onView={() => openModal(weapon)}
              onEdit={() => openForm(weapon)}
              onToggleCompare={() => toggleComparison(weapon)}
              isCompared={comparisonList.some(w => w.id === weapon.id)}
            />
          ))}
        </div>

        {comparisonList.length > 1 && (
          <div className="mt-6 text-center">
            <button
              className="bg-blue-600 text-white px-5 py-3 rounded hover:bg-blue-700"
              onClick={openComparison}
            >
              Compare Selected Weapons ({comparisonList.length})
            </button>
          </div>
        )}
      </main>

      {isModalOpen && selectedWeapon && (
        <WeaponModal weapon={selectedWeapon} onClose={closeModal} />
      )}

      {isFormOpen && (
        <WeaponForm
          weapon={weaponToEdit}
          onClose={closeForm}
          onSave={saveWeapon}
        />
      )}

      {isComparisonOpen && (
        <ComparisonModal
          weapons={comparisonList}
          onClose={closeComparison}
        />
      )}
    </div>
  );
}

export default App;
